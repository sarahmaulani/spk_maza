from django.apps import AppConfig


class SpkConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'spk'

    def ready(self):
        import spk.signals
